package com.aydym.pleyer

import android.net.Uri

/** Bir aýdymyň maglumaty. */
data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri,
    val folderPath: String
) {
    val folderName: String
        get() = folderPath.substringAfterLast('/').ifBlank { "/" }
}
