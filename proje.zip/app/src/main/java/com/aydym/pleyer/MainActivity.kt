package com.aydym.pleyer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AppRoot()
            }
        }
    }
}

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

private fun permissionsToRequest(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) {
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
    } else {
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

private fun hasAudioPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, audioPermission()) ==
        PackageManager.PERMISSION_GRANTED

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasAudioPermission(context)) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted = hasAudioPermission(context) }

    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(permissionsToRequest())
    }
    LaunchedEffect(granted) {
        if (granted) vm.loadSongs()
    }

    if (granted) {
        PlayerScreen(vm)
    } else {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(stringResource(R.string.permission_title), style = MaterialTheme.typography.headlineSmall)
            Text(
                stringResource(R.string.permission_text),
                modifier = Modifier.padding(vertical = 16.dp)
            )
            Button(onClick = { launcher.launch(permissionsToRequest()) }) {
                Text(stringResource(R.string.permission_button))
            }
        }
    }
}

private data class Group(val key: String, val title: String, val songs: List<Song>)

@Composable
fun PlayerScreen(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val titles = listOf(
        stringResource(R.string.tab_songs),
        stringResource(R.string.tab_artists),
        stringResource(R.string.tab_folders)
    )

    // Aýdym oýnanda ýagdaýy yzygiderli täzelemek (süýşürgiç üçin)
    LaunchedEffect(vm.isPlaying) {
        while (vm.isPlaying) {
            vm.tick()
            delay(500)
        }
    }

    val byArtist = remember(vm.songs) {
        vm.songs.groupBy { it.artist }
            .map { (k, v) -> Group(k, k, v) }
            .sortedBy { it.title.lowercase() }
    }
    val byFolder = remember(vm.songs) {
        vm.songs.groupBy { it.folderPath }
            .map { (k, v) -> Group(k, v.first().folderName, v) }
            .sortedBy { it.title.lowercase() }
    }

    Scaffold(bottomBar = { MiniPlayer(vm) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                titles.forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
                }
            }
            when {
                !vm.loaded -> CenterText(stringResource(R.string.loading))
                vm.songs.isEmpty() -> CenterText(stringResource(R.string.no_songs))
                tab == 0 -> SongList(vm, vm.songs)
                tab == 1 -> GroupedList(vm, byArtist)
                else -> GroupedList(vm, byFolder)
            }
        }
    }
}

@Composable
private fun CenterText(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(text) }
}

@Composable
private fun SongRow(song: Song, isCurrent: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(
            song.title,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
            color = if (isCurrent) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurface
        )
        Text(
            song.artist,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun SongList(vm: MainViewModel, songs: List<Song>) {
    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
            SongRow(s, vm.currentId == s.id.toString()) { vm.play(songs, i) }
        }
    }
}

@Composable
private fun GroupedList(vm: MainViewModel, groups: List<Group>) {
    LazyColumn(Modifier.fillMaxSize()) {
        groups.forEach { g ->
            item(key = "h_${g.key}") {
                Text(
                    "${g.title} (${g.songs.size})",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            itemsIndexed(g.songs, key = { _, s -> "${g.key}_${s.id}" }) { i, s ->
                SongRow(s, vm.currentId == s.id.toString()) { vm.play(g.songs, i) }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

@Composable
private fun MiniPlayer(vm: MainViewModel) {
    if (vm.currentId == null) return
    var dragging by remember { mutableStateOf<Float?>(null) }
    val max = vm.durationMs.coerceAtLeast(1L).toFloat()

    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text(
                vm.currentTitle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Bold
            )
            Text(
                vm.currentArtist,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall
            )
            Slider(
                value = (dragging ?: vm.positionMs.toFloat()).coerceIn(0f, max),
                onValueChange = { dragging = it },
                onValueChangeFinished = {
                    dragging?.let { vm.seekTo(it.toLong()) }
                    dragging = null
                },
                valueRange = 0f..max
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime((dragging ?: vm.positionMs.toFloat()).toLong()), style = MaterialTheme.typography.bodySmall)
                Text(formatTime(vm.durationMs), style = MaterialTheme.typography.bodySmall)
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = { vm.previous() }, modifier = Modifier.weight(1f)) {
                    Text("⏮ " + stringResource(R.string.previous), maxLines = 1)
                }
                Button(onClick = { vm.togglePlay() }, modifier = Modifier.weight(1f)) {
                    Text(
                        if (vm.isPlaying) "⏸ " + stringResource(R.string.pause)
                        else "▶ " + stringResource(R.string.play),
                        maxLines = 1
                    )
                }
                OutlinedButton(onClick = { vm.next() }, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.next) + " ⏭", maxLines = 1)
                }
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = vm.shuffle,
                    onClick = { vm.toggleShuffle() },
                    label = { Text(stringResource(R.string.shuffle)) }
                )
                FilterChip(
                    selected = vm.repeatMode != Player.REPEAT_MODE_OFF,
                    onClick = { vm.cycleRepeat() },
                    label = {
                        Text(
                            when (vm.repeatMode) {
                                Player.REPEAT_MODE_ALL -> stringResource(R.string.repeat_all)
                                Player.REPEAT_MODE_ONE -> stringResource(R.string.repeat_one)
                                else -> stringResource(R.string.repeat_off)
                            }
                        )
                    }
                )
            }
        }
    }
}
