package com.aydym.pleyer

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore

/** Telefonyň ýadyndaky ähli aýdymlary MediaStore arkaly awtomatiki tapýar (internet gerek däl). */
object MusicRepository {

    @Suppress("DEPRECATION")
    fun loadSongs(context: Context): List<Song> {
        val songs = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val unknownArtist = context.getString(R.string.unknown_artist)

        context.contentResolver.query(
            collection, projection, selection, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)

            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val artistRaw = c.getString(artistCol)
                val artist = if (artistRaw.isNullOrBlank() || artistRaw == "<unknown>") {
                    unknownArtist
                } else {
                    artistRaw
                }
                val path = c.getString(dataCol).orEmpty()
                songs.add(
                    Song(
                        id = id,
                        title = c.getString(titleCol) ?: "?",
                        artist = artist,
                        album = c.getString(albumCol).orEmpty(),
                        durationMs = c.getLong(durCol),
                        uri = ContentUris.withAppendedId(collection, id),
                        folderPath = path.substringBeforeLast('/', "")
                    )
                )
            }
        }
        return songs
    }
}
